<?php // $Id$ ?>
<div class="<?php print $classes; ?>">
  <?php print $content; ?>
</div> <!-- /.region -->
