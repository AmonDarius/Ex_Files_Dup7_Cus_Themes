Use this example layout template and configuration as a starting point for your
own, custom Display Suite layouts.

Use the Drush command to set things up even faster:

$ drush ds-build "My layout name" --regions="Region 1, Region 2"

Type "drush help ds-build" for more help.
